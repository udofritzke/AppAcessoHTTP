package com.example.twitterapi;

public class DadosTweet {
    private String mId;
    private String mText;

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        mText = text;
    }
}
